<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Mount_Everest
 */

?>


<!-- <div class="card col-12 col-md-6 col-lg-4 p-4">
    <img class="d-none d-md-block" src="${this.img}" class="card-img-top" alt="...">
    <div class="card-body px-2 pt-2 pb-0">
        <h5 class="card-title py-2 mb-1 main-color font-size-17">${this.name}<br><small>${this.type}</small></h5>
        <span class="text-muted"><small>Created: ${this.createdDateTime}</small></span>
        <p class="card-text my-3">${this.description}</p>
        <ul class="list-group list-group-flush">
            <li class="list-group-item px-2"><i class="fas fa-map-marker-alt"></i> ${this.address}, ${this.zipCode} Vienna</li>
			${this.moreInfo}
        </ul>
    </div>
    <hr class="col-12 m-0 p-0">
</div> -->




<div class="card col-12 col-md-6 col-lg-4 px-4 pb-5">
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="card-body p-3 border rounded-10 bg-light">
			
	<?php mount_everest_post_thumbnail(); ?>
	<header class="entry-header pt-3 text-center">
		<?php
		if ( is_singular() ) :
			the_title( '<h1 class="entry-title">', '</h1>' );
		else :
			the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
		endif;

		if ( 'post' === get_post_type() ) :
			?>
			<div class="entry-meta text-muted">
				<?php
				mount_everest_posted_on();
				// mount_everest_posted_by();
				?>
			</div><!-- .entry-meta -->
		<?php endif; ?>
	</header><!-- .entry-header -->


	<div class="entry-content">
		<?php
		the_content( sprintf(
			wp_kses(
				/* translators: %s: Name of current post. Only visible to screen readers */
				__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'mount-everest' ),
				array(
					'span' => array(
						'class' => array(),
					),
				)
			),
			get_the_title()
		) );

		wp_link_pages( array(
			'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'mount-everest' ),
			'after'  => '</div>',
		) );
		?>
	</div><!-- .entry-content -->

	<footer class="entry-footer text-center">
		<?php mount_everest_entry_footer(); ?>
	</footer><!-- .entry-footer -->
	</div>
</article><!-- #post-<?php the_ID(); ?> -->
</div>